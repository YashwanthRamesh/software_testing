import com.intuit.karate.junit5.Karate;
import com.intuit.karate.junit5.Karate.Test;
public class deletemethod {
	@Test
	public Karate runTest()
	{
		return Karate.run("delete").relativeTo(getClass());
	}
	
}